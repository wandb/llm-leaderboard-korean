"""
Setup script for haerae-evaluation-toolkit.
This file is kept for compatibility purposes.
The actual configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()